import sys
sys.stdout.reconfigure(encoding='utf-8')

with open("assets/index-ZIdIQXhF-v5.js", "r", encoding="utf-8") as f:
    js = f.read()

import re
# Find YouTube player initialization
matches = list(re.finditer(r'new\s+window\.YT\.Player|loadVideoById|playVideo', js))
print(f"Found {len(matches)} matches for YT player methods")
for i, m in enumerate(matches):
    start = m.start()
    print(f"Match {i}: {repr(js[max(0, start-100):min(len(js), start+200)])}")
    print("-" * 60)
