'use client';
import React, { useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Heart, ListMusic, Zap, Repeat } from 'lucide-react';
import { formatTime } from '../lib/youtube';

export default function PlayerFooter({
  currentSong,
  isPlaying,
  onTogglePlay,
  onPlayPause,
  onSkipNext,
  onSkipPrev,
  currentTime = 0,
  duration = 100,
  onSeek,
  volume = 0.8,
  onVolumeChange,
  history = [],
  likedSongs = [],
  onToggleLike,
  queue = [],
  onToggleQueue,
  isQueueOpen,
  isLooping = false,
  onToggleLoop
}) {
  const [isMuted, setIsMuted] = useState(false);
  const isLiked = currentSong && likedSongs.some((s) => s.id === currentSong.id);
  const handlePlayClick = onTogglePlay || onPlayPause;

  const handleSliderSeek = (e) => {
    const newSec = parseFloat(e.target.value);
    if (onSeek) {
      onSeek(newSec);
    }
  };

  return (
    <footer className="fixed bottom-0 left-0 right-0 bg-[#0B0F19]/95 backdrop-blur-md border-t border-white/5 p-3 px-4 sm:px-6 flex items-center justify-between gap-3 sm:gap-4 z-40 select-none shadow-2xl">
      {/* Left: Track Info */}
      <div className="flex items-center gap-3 w-1/4 min-w-[170px] max-w-[280px]">
        <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-[#141C30] border border-white/10 overflow-hidden shrink-0 shadow-md">
          {currentSong?.thumbnail ? (
            <img src={currentSong.thumbnail} alt={currentSong.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-emerald-400 font-black text-xs">
              Sync
            </div>
          )}
        </div>
        <div className="flex flex-col min-w-0 flex-1">
          <h4 className="text-xs font-bold text-white truncate">{currentSong?.title || 'No song playing'}</h4>
          <p className="text-[11px] text-zinc-400 truncate">{currentSong?.artist || 'Pick a track or join a room'}</p>
        </div>
        {currentSong && onToggleLike && (
          <button
            onClick={() => onToggleLike(currentSong)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer shrink-0 ${
              isLiked ? 'text-pink-500 bg-pink-500/10' : 'text-zinc-500 hover:text-white'
            }`}
            title={isLiked ? 'Unlike track' : 'Like track'}
          >
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-pink-500 text-pink-500' : ''}`} />
          </button>
        )}
      </div>

      {/* Middle: Controls & Progress */}
      <div className="flex flex-col items-center gap-1.5 flex-1 max-w-xl min-w-0">
        <div className="flex items-center gap-3 sm:gap-5">
          {/* Loop / Repeat Button */}
          <button
            onClick={onToggleLoop}
            className={`p-2 rounded-xl transition-all cursor-pointer ${
              isLooping
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-sm'
                : 'text-zinc-400 hover:text-white hover:bg-white/5'
            }`}
            title={isLooping ? 'Loop Song: ON (Click to Disable)' : 'Loop Song: OFF (Click to Enable)'}
          >
            <Repeat className="w-4 h-4" />
          </button>

          <button
            onClick={onSkipPrev}
            disabled={history.length <= 1}
            className="text-zinc-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
            title="Previous Track"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            onClick={handlePlayClick}
            className="w-10 h-10 rounded-full bg-emerald-500 hover:bg-emerald-400 text-black flex items-center justify-center shadow-lg shadow-emerald-500/25 hover:scale-105 active:scale-95 transition-all cursor-pointer font-bold shrink-0"
            title={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-black" /> : <Play className="w-4 h-4 ml-0.5 fill-black" />}
          </button>

          <button
            onClick={onSkipNext}
            className="text-zinc-400 hover:text-white transition-colors cursor-pointer"
            title="Next Track"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          {/* Queue Drawer Trigger */}
          {onToggleQueue && (
            <button
              onClick={onToggleQueue}
              className={`p-2 px-2.5 rounded-xl border transition-all flex items-center gap-1.5 text-[11px] font-bold cursor-pointer shrink-0 ${
                isQueueOpen
                  ? 'bg-emerald-500 text-black border-emerald-400 shadow-md shadow-emerald-500/20'
                  : 'bg-[#141C30] text-zinc-300 border-white/5 hover:bg-[#1a2540]'
              }`}
              title="Toggle Playback Queue"
            >
              <ListMusic className="w-3.5 h-3.5" />
              <span>Queue {queue.length > 0 ? `(${queue.length})` : ''}</span>
            </button>
          )}
        </div>

        {/* Seek Bar */}
        <div className="flex items-center gap-2 sm:gap-3 w-full text-[10px] text-zinc-400 font-mono">
          <span className="w-8 text-right shrink-0">{formatTime(currentTime)}</span>
          <input
            type="range"
            min="0"
            max={duration > 0 ? duration : 100}
            step="1"
            value={currentTime || 0}
            onChange={handleSliderSeek}
            className="flex-1 h-1.5 bg-[#141C30] rounded-lg appearance-none cursor-pointer accent-emerald-400 min-w-[80px]"
          />
          <span className="w-8 shrink-0">{formatTime(duration)}</span>
        </div>
      </div>

      {/* Right: Volume & Ultra Low Data Badge */}
      <div className="flex items-center justify-end gap-3 sm:gap-4 w-1/4 min-w-[130px] max-w-[220px]">
        <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold font-mono shrink-0">
          <Zap className="w-3 h-3 fill-emerald-400" />
          <span>~1MB Pure Audio</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="text-zinc-400 hover:text-white transition-colors cursor-pointer shrink-0"
          >
            {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={isMuted ? 0 : volume}
            onChange={(e) => {
              setIsMuted(false);
              onVolumeChange && onVolumeChange(parseFloat(e.target.value));
            }}
            className="w-16 sm:w-20 h-1.5 bg-[#141C30] rounded-lg appearance-none cursor-pointer accent-emerald-400"
          />
        </div>
      </div>
    </footer>
  );
}
